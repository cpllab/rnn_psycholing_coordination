|Experiment| Conditions | Sentences| 
| :---:         | :---:         |     :---:      |     
| and-coordination |and_Nm_Nm_Vm <br> and_Nm_Nm_Vf <br>  and_Nm_Nf_Vm <br>  and_Nm_Nf_Vf <br> and_Nf_Nm_Vm <br> and_Nf_Nm_Vf <br> and_Nf_Nf_Vm<br> and_Nf_Nf_Vf | The door and the window is<br> That the door and the window are <br> The door and the windows is <br> The door and the windows are <br> The doors and the window is <br> The doors and the window are  <br>  The doors and the windows is <br>  The doors and the windows are   |  




