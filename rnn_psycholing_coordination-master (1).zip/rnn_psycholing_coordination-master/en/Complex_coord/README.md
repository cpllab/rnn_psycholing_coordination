

|Experiment| Conditions | Sentences| 
| :---:         | :---:         |     :---:      |     
| Control |Nsg_and_Nsg_Vsg <br> Nsg_and_Nsg_Vpl <br>  Nsg_and_Npl_Vsg <br> Nsg_and_Npl_Vpl <br>Npl_and_Nsg_Vsg <br> Npl_and_Nsg_Vpl <br> Npl_and_Npl_Vsg<br> Npl_and_Npl_Vpl | I think that the door and the window is<br> I think that the door and the window are <br> I think that the door and the windows is <br> I think that the door and the windows are <br> I think that the doors and the window is <br> I think that the doors and the window are  <br>  I think that The doors and the windows is <br>  I think that the doors and the windows are   |  
| Critical  |Nsg_and_Nsg_Vsg <br> Nsg_and_Nsg_Vpl <br>  Nsg_and_Npl_Vsg <br> Nsg_and_Npl_Vpl <br>Npl_and_Nsg_Vsg <br> Npl_and_Nsg_Vpl <br> Npl_and_Npl_Vsg<br> Npl_and_Npl_Vpl | I fixed the door and the window is<br> I fixed the door and the window are <br> I fixed the door and the windows is <br> I fixed the door and the windows are <br> I fixed the doors and the window is <br> I fixed the doors and the window are  <br>  I fixed The doors and the windows is <br>  I fixed the doors and the windows are   |  
