# Simple Coordination Experiment

|Experiment| Conditions | Sentences| 
| :---:         | :---:         |     :---:      |     
| and-coordination |and_sg_sg_Vsg <br> and_sg_sg_Vsg_Vpl <br>  and_sg_pl_Vsg_Vsg <br>  and_sg_pl_Npl_Vpl <br> and_pl_sg_Vsg <br> and_pl_sg_Vpl <br> and_pl_pl_Vsg<br> and_pl_pl_Vpl | The door and the window is<br> That the door and the window are <br> The door and the windows is <br> The door and the windows are <br> The doors and the window is <br> The doors and the window are  <br>  The doors and the windows is <br>  The doors and the windows are   |  
| or-coordination  |or_sg_sg_Vsg <br> or_sg_sg_Vsg_Vpl <br>  or_sg_pl_Vsg_Vsg <br>  or_sg_pl_Npl_Vpl <br> or_pl_sg_Vsg <br> or_pl_sg_Vpl <br> or_pl_pl_Vsg<br> or_pl_pl_Vpl  | The door or the window is<br> That the door or the window are <br> The door or the windows is <br> The door or the windows are <br> The doors or the window is <br> The doors or the window are  <br>  The doors or the windows is <br>  The doors or the windows are   |  



